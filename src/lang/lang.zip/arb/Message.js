export default {
    title: {
        first: 'Please left your message or question and we will answer it. But ',
        red: 'you must be sure to specify your phone number or email ',
        second: 'so that we can get touch with you.'
    },

    form: {
        email: 'Enter your email or phone number',
        name: 'Enter full name',
        country: 'Enter your country',
        message: 'Enter your question or message',
        button: 'Send message'
    }

}